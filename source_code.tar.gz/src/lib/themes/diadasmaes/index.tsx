// Dia das Mães Theme Module
// Exports all Mother's Day theme components for use by the registry

export { diadasmaesTheme } from './config';
export { DiadasmaesDecorations, DiadasmaesFloatingIcons, DiadasmaesPetals } from './decorations';
export { DiadasmaesModal, diadasmaesLockedConfig } from './modals';
