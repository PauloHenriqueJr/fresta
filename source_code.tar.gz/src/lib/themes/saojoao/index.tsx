// São João Theme Module
// Exports all São João theme components for use by the registry

export { saojoaoTheme } from './config';
export { SaoJoaoDecorations, SaoJoaoBandeirinhas, SaoJoaoFloatingIcons } from './decorations';
export { SaoJoaoBarracaModal, saojoaoLockedConfig } from './modals';
