// Metas (Goals) Theme Module
// Exports all Goals/New Beginnings theme components for use by the registry

export { metasTheme } from './config';
export { MetasDecorations, MetasFloatingIcons, MetasStars, MetasShootingStar } from './decorations';
export { MetasGoalModal, metasLockedConfig } from './modals';
