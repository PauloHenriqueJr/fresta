// Dia dos Pais Theme Module
// Exports all Father's Day theme components for use by the registry

export { diadospaisTheme } from './config';
export { DiadospaisDecorations, DiadospaisFloatingIcons, DiadospaisStripes } from './decorations';
export { DiadospaisModal, diadospaisLockedConfig } from './modals';
