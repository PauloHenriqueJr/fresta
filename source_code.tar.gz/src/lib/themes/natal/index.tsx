// Natal Theme Module
// Exports all Natal (Christmas) theme components for use by the registry

export { natalTheme } from './config';
export { NatalDecorationsFull, NatalGuirlanda, NatalNeve, NatalFloatingIcons, NatalLuzes } from './decorations';
export { NatalFireworksModal, natalLockedConfig } from './modals';
