import { Outlet, useNavigate, useLocation } from "react-router-dom";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import B2CSidebar from "@/components/b2c/B2CSidebar";
import { useAuth } from "@/state/auth/AuthProvider";
import { Plus, Search, Calendar, Home, Moon, Sun, Sparkles, Briefcase, Shield } from "lucide-react";
import { motion } from "framer-motion";
import UserAvatar from "@/components/UserAvatar";
import { cn } from "@/lib/utils";

export default function B2CLayout() {
  const { user, profile, logout, themePreference, updateThemePreference, role } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const isTabActive = (path: string) => location.pathname === path;
  const isCreationFlow = location.pathname.startsWith("/criar") || location.pathname.startsWith("/editar-dia") || location.pathname.includes("/configuracoes");

  return (
    <SidebarProvider>
      <div className="min-h-screen w-full bg-background">
        {/* Desktop app shell (lg+) */}
        <div className="hidden lg:flex min-h-screen w-full">
          <B2CSidebar />

          <div className="flex-1 min-w-0">
            {/* Header - Premium Glassmorphic Solidroad style (Matching B2B) */}
            <header className="h-20 flex items-center justify-between px-8 sticky top-0 z-40 border-b border-border/10 bg-white/80 dark:bg-[#0E220E]/80 backdrop-blur-xl transition-colors duration-300">
              <div className="flex items-center gap-4">
                <SidebarTrigger className="hover:bg-muted transition-colors rounded-lg p-2 text-solidroad-text dark:text-white/80" />
                <div className="h-5 w-px bg-border/10" />
                <div className="flex flex-col">
                  <span className="text-[11px] font-black uppercase tracking-widest text-muted-foreground/60 dark:text-white/40">
                    Olá, {profile?.display_name?.split(' ')[0] || 'usuário'}
                  </span>
                  <span className="text-lg font-medium tracking-tight text-solidroad-text dark:text-[#F6D045] -mt-0.5">Painel Central</span>
                </div>
              </div>

              {/* Micro-frase (Opção 2 - Sussurro Visual) */}
              <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 hidden xl:block">
                <span className="text-sm font-serif italic text-muted-foreground/40 tracking-wide select-none">
                  "Cuidar também é uma forma de lembrar."
                </span>
              </div>

              <div className="flex items-center gap-4">
                <div className="hidden xl:flex items-center bg-muted/50 dark:bg-card rounded-2xl px-4 py-2.5 border border-border/10 group focus-within:border-solidroad-accent/50 focus-within:ring-2 focus-within:ring-solidroad-accent/10 transition-all">
                  <Search className="w-4 h-4 text-muted-foreground/60 mr-2" />
                  <input
                    type="text"
                    placeholder="Busca global..."
                    className="bg-transparent border-none outline-none text-sm w-64 placeholder:text-muted-foreground/40 font-medium text-foreground"
                  />
                </div>

                {/* Dark Mode Toggle */}
                <button
                  onClick={() => {
                    const nextTheme = themePreference === "dark" ? "light" : "dark";
                    updateThemePreference(nextTheme);
                  }}
                  className="w-10 h-10 rounded-xl flex items-center justify-center bg-muted/50 dark:bg-card text-foreground dark:text-solidroad-accent transition-all hover:scale-105 border border-border/10"
                  title="Alternar modo claro/escuro"
                >
                  {themePreference === "dark" ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
                </button>

                {/* Dashboard Switcher - Only for Admin/RH */}
                {(role === 'admin' || role === 'rh') && (
                  <div className="flex items-center gap-1 bg-muted/50 dark:bg-card rounded-xl p-1 border border-border/10">
                    <button
                      onClick={() => navigate("/b2b")}
                      className="w-9 h-9 rounded-lg flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-background/50 transition-all"
                      title="Ir para B2B"
                    >
                      <Briefcase className="w-4 h-4" />
                    </button>
                    {role === 'admin' && (
                      <button
                        onClick={() => navigate("/admin")}
                        className="w-9 h-9 rounded-lg flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-background/50 transition-all"
                        title="Ir para Admin"
                      >
                        <Shield className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                )}

                <button
                  onClick={() => navigate("/plus")}
                  className="px-6 py-2.5 rounded-xl bg-solidroad-accent text-solidroad-text text-sm font-black shadow-glow-accent hover:scale-105 transition-all flex items-center gap-2"
                >
                  <Sparkles className="w-4 h-4" />
                  Fazer Upgrade
                </button>
              </div>
            </header>

            <main className="p-8 lg:p-12 xl:p-16 max-w-[1600px] mx-auto w-full">
              <Outlet />
            </main>
          </div>
        </div>

        {/* Mobile/Tablet: mantém exatamente como está (sem shell) */}
        <div className={`lg:hidden flex-1 flex flex-col relative ${isCreationFlow ? "" : "pb-24"}`}>
          <main className="flex-1 overflow-x-hidden">
            <Outlet />
          </main>

          {/* SHARED BOTTOM NAV - MOBILE ONLY */}
          {!isCreationFlow && (
            <div className="fixed bottom-0 left-0 right-0 z-[100] safe-area-bottom bg-background/80 backdrop-blur-xl border-t border-border/40 px-2 py-1">
              <nav className="flex items-center justify-around max-w-lg mx-auto h-16 relative">

                {/* INÍCIO (Home discovery) */}
                <button
                  onClick={() => navigate("/explorar")}
                  className={`flex flex-col items-center justify-center gap-1 flex-1 h-full transition-all ${isTabActive("/explorar") && !location.search.includes('q=') ? "text-primary" : "text-muted-foreground/60 hover:text-foreground"
                    }`}
                >
                  <div className={`p-1.5 rounded-xl transition-colors ${isTabActive("/explorar") && !location.search.includes('q=') ? "bg-primary/10" : ""}`}>
                    <Home className="w-6 h-6" />
                  </div>
                  <span className="text-[9px] font-black uppercase tracking-widest">Início</span>
                </button>

                {/* CALENDÁRIOS */}
                <button
                  onClick={() => navigate("/meus-calendarios")}
                  className={`flex flex-col items-center justify-center gap-1 flex-1 h-full transition-all ${isTabActive("/meus-calendarios") ? "text-primary" : "text-muted-foreground/60 hover:text-foreground"
                    }`}
                >
                  <div className={`p-1.5 rounded-xl transition-colors ${isTabActive("/meus-calendarios") ? "bg-primary/10" : ""}`}>
                    <Calendar className="w-6 h-6" />
                  </div>
                  <span className="text-[9px] font-black uppercase tracking-widest text-center">Calendários</span>
                </button>

                {/* NOVO (+) */}
                <div className="flex-1 flex justify-center -mt-8">
                  <motion.button
                    className="bg-primary text-primary-foreground w-14 h-14 rounded-2xl flex items-center justify-center shadow-lg shadow-primary/20 hover:scale-105 active:scale-95 transition-all"
                    onClick={() => navigate("/criar")}
                    whileTap={{ scale: 0.9 }}
                  >
                    <Plus className="w-8 h-8" strokeWidth={3} />
                  </motion.button>
                </div>

                {/* EXPLORAR */}
                <button
                  onClick={() => navigate("/explorar")}
                  className={`flex flex-col items-center justify-center gap-1 flex-1 h-full transition-all ${isTabActive("/explorar") ? "text-primary" : "text-muted-foreground/60 hover:text-foreground"
                    }`}
                >
                  <div className={`p-1.5 rounded-xl transition-colors ${isTabActive("/explorar") ? "bg-primary/10" : ""}`}>
                    <Search className="w-6 h-6" />
                  </div>
                  <span className="text-[9px] font-black uppercase tracking-widest">Explorar</span>
                </button>

                {/* PERFIL */}
                <button
                  onClick={() => navigate("/perfil")}
                  className={`flex flex-col items-center justify-center gap-1 flex-1 h-full transition-all ${isTabActive("/perfil") ? "text-primary" : "text-muted-foreground/60 hover:text-foreground"
                    }`}
                >
                  <div className={`relative flex items-center justify-center rounded-xl p-0.5 transition-colors ${isTabActive("/perfil") ? "bg-primary/10" : ""}`}>
                    <UserAvatar size="sm" className={cn(isTabActive("/perfil") ? "border-primary" : "border-border/50")} />
                  </div>
                  <span className="text-[9px] font-black uppercase tracking-widest">Perfil</span>
                </button>
              </nav>
            </div>
          )}
        </div>
      </div>
    </SidebarProvider>
  );
}
